import{a as t}from"../chunks/entry.C7K34a8r.js";export{t as start};
